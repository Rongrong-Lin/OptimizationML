prox.py---The proximal operator of various penalties

Algo.py---ISTA algorithm

DCT_matrix.ipynb---Compressive sensing in the case of DCT matrices

Gaussian_matrix.ipynb---Compressive sensing in the case of Gaussian matrices

Computing the proximal operator of PiE.ipynb---Images of the proximal operator of PiE

All the experiments below are run on a PC with Intel i5 CPU 2.5 GHz and 16 GB RAM, the numerical results are obtained via Python 3.9 and Jupyter Notebook 6.4.12.
