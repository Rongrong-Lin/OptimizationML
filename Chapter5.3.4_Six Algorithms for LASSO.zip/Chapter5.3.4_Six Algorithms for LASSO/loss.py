import torch
def nmse(x, x_gt):
    l2 = ((x - x_gt) ** 2).mean()
    denom = (x_gt ** 2).mean()
    val = 10.0 * torch.log10(l2 / denom)
    return val

def relative_error(x_hat:torch.Tensor, x_gt:torch.Tensor):
    # l2 = ((x - x_gt) ** 2).mean()
    # denom = (x_gt ** 2).mean()
    # val = l2 / denom
    return ((x_hat - x_gt) ** 2).sum()/(x_gt.norm()**2+1e-5).data.item()
#